# Jaya Obsidian Vault Export

**World:** Curse of the Bone-Magician
**Adventure:** Wraiths Beneath the Tower

## Quick start

1. Drop the contents of this zip's `Jaya/` folder into your Obsidian vault.
2. (Optional) Copy `_jaya/jaya-styles.css` into `<vault>/.obsidian/snippets/`,
   then in **Settings → Appearance → CSS snippets**, toggle `jaya-styles` on.
   Without the snippet your vault still works — just with neutral callout colors.

## Re-import to update

Drop a newer zip from the same world over the same vault location. The
`obsidian-jaya-import` plugin (recommended) preserves any prose you've
written outside the `<!-- jaya:begin -->` / `<!-- jaya:end -->` markers
on existing notes. The Python helper at `tools/jaya_obsidian_import.py`
in the Jaya repo does the same from the command line.

## Format version

`_jaya/manifest.json` lists `formatVersion: 1`. The wire-format spec
ships at `docs/obsidian-export-format/spec.md` in the Jaya repo.